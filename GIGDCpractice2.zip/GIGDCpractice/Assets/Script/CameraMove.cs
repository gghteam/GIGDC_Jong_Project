﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMove : MonoBehaviour
{
    [SerializeField] private GameObject player;
    //[SerializeField] private GameObject Camera;
    private void Start()
    {
        Vector3 pve = player.transform.position;
        
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}
